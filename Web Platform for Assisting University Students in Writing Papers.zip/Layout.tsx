/*
 * Layout.tsx - 공통 레이아웃 컴포넌트
 * Design: Clean Scholar - Deep Indigo nav with off-white background
 * Noto Serif KR logo, Noto Sans KR nav items
 */

import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { Menu, X, BookOpen, Quote, Download } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

const navItems = [
  { href: "/guide", label: "작성 가이드", icon: BookOpen },
  { href: "/citation", label: "인용 생성기", icon: Quote },
  { href: "/templates", label: "템플릿", icon: Download },
];

export default function Layout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 10);
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  useEffect(() => {
    setMobileOpen(false);
  }, [location]);

  return (
    <div className="min-h-screen flex flex-col bg-background">
      {/* Header */}
      <header
        className={cn(
          "fixed top-0 left-0 right-0 z-50 transition-all duration-200",
          scrolled
            ? "bg-white/95 backdrop-blur-md shadow-sm border-b border-border"
            : "bg-white border-b border-border"
        )}
      >
        <div className="container">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <Link href="/" className="flex items-center gap-2.5 group">
              <div className="w-8 h-8 rounded-md overflow-hidden flex-shrink-0">
                <img
                  src="https://d2xsxph8kpxj0f.cloudfront.net/310519663762868322/CsRvtfedZ8KzkwHQEF6Zir/logo-icon-K35ukTNjYoMoumbLdKXsKN.webp"
                  alt="논문 도우미 로고"
                  className="w-full h-full object-contain"
                />
              </div>
              <span
                className="text-lg font-bold tracking-tight"
                style={{
                  fontFamily: "'Noto Serif KR', serif",
                  color: "var(--brand-indigo)",
                }}
              >
                논문 도우미
              </span>
            </Link>

            {/* Desktop Nav */}
            <nav className="hidden md:flex items-center gap-1">
              {navItems.map(({ href, label, icon: Icon }) => (
                <Link key={href} href={href}>
                  <span
                    className={cn(
                      "relative flex items-center gap-1.5 px-3 py-2 rounded-md text-sm font-medium transition-colors duration-150",
                      location === href
                        ? "bg-primary/8 text-primary"
                        : "text-muted-foreground hover:text-foreground hover:bg-muted"
                    )}
                    style={
                      location === href
                        ? { color: "var(--brand-indigo)", backgroundColor: "oklch(0.28 0.08 240 / 0.08)" }
                        : {}
                    }
                  >
                    <Icon size={15} />
                    {label}
                    {location === href && (
                      <span
                        className="absolute bottom-0 left-3 right-3 h-0.5 rounded-full"
                        style={{ backgroundColor: "var(--brand-indigo)" }}
                      />
                    )}
                  </span>
                </Link>
              ))}
            </nav>

            {/* Mobile menu button */}
            <Button
              variant="ghost"
              size="icon"
              className="md:hidden"
              onClick={() => setMobileOpen(!mobileOpen)}
              aria-label="메뉴 열기"
            >
              {mobileOpen ? <X size={20} /> : <Menu size={20} />}
            </Button>
          </div>
        </div>

        {/* Mobile Nav */}
        {mobileOpen && (
          <div className="md:hidden border-t border-border bg-white">
            <nav className="container py-3 flex flex-col gap-1">
              {navItems.map(({ href, label, icon: Icon }) => (
                <Link key={href} href={href}>
                  <span
                    className={cn(
                      "flex items-center gap-2.5 px-3 py-2.5 rounded-md text-sm font-medium transition-colors",
                      location === href
                        ? "text-white"
                        : "text-foreground hover:bg-muted"
                    )}
                    style={
                      location === href
                        ? { backgroundColor: "var(--brand-indigo)" }
                        : {}
                    }
                  >
                    <Icon size={16} />
                    {label}
                  </span>
                </Link>
              ))}
            </nav>
          </div>
        )}
      </header>

      {/* Main content */}
      <main className="flex-1 pt-16">
        <div className="page-enter">{children}</div>
      </main>

      {/* Footer */}
      <footer className="border-t border-border bg-white mt-auto">
        <div className="container py-8">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded overflow-hidden">
                <img
                  src="https://d2xsxph8kpxj0f.cloudfront.net/310519663762868322/CsRvtfedZ8KzkwHQEF6Zir/logo-icon-K35ukTNjYoMoumbLdKXsKN.webp"
                  alt=""
                  className="w-full h-full object-contain"
                />
              </div>
              <span
                className="text-sm font-semibold"
                style={{ fontFamily: "'Noto Serif KR', serif", color: "var(--brand-indigo)" }}
              >
                논문 도우미
              </span>
            </div>
            <p className="text-xs text-muted-foreground text-center">
              대학생 논문 작성 지원 플랫폼 · 인용 형식, 더 이상 헷갈리지 마세요
            </p>
            <div className="flex items-center gap-4">
              {navItems.slice(0, 3).map(({ href, label }) => (
                <Link key={href} href={href}>
                  <span className="text-xs text-muted-foreground hover:text-foreground transition-colors">
                    {label}
                  </span>
                </Link>
              ))}
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
