import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, json } from "drizzle-orm/mysql-core";
import { relations } from "drizzle-orm";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * 사용자가 저장한 인용 자료 테이블
 * 각주/참고문헌 생성기에서 저장한 자료 목록을 저장
 */
export const citations = mysqlTable("citations", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  /** 자료 유형: book, journal, web */
  type: mysqlEnum("type", ["book", "journal", "web"]).notNull(),
  /** 저자명 */
  author: varchar("author", { length: 255 }).notNull(),
  /** 제목 */
  title: varchar("title", { length: 500 }).notNull(),
  /** 출판사/학술지명 */
  publisher: varchar("publisher", { length: 255 }),
  /** 발행연도 */
  year: int("year"),
  /** 추가 정보 (쪽수, URL 등) */
  additionalInfo: text("additionalInfo"),
  /** 생성된 각주 목록 (JSON 형식) */
  generatedFootnotes: json("generatedFootnotes").$type<{
    korean: string;
    apa: string;
    mla: string;
    chicago: string;
    krfoundation: string;
  }>(),
  /** 저장 시간 */
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Citation = typeof citations.$inferSelect;
export type InsertCitation = typeof citations.$inferInsert;

/**
 * 사용자가 다운로드한 템플릿 기록 테이블
 * 템플릿 사용 통계 및 사용자 활동 추적
 */
export const templateDownloads = mysqlTable("templateDownloads", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  /** 템플릿 이름: academic, thesis, report */
  templateName: varchar("templateName", { length: 50 }).notNull(),
  /** 다운로드 시간 */
  downloadedAt: timestamp("downloadedAt").defaultNow().notNull(),
});

export type TemplateDownload = typeof templateDownloads.$inferSelect;
export type InsertTemplateDownload = typeof templateDownloads.$inferInsert;

/**
 * 사용자가 생성한 참고문헌 목록 저장 테이블
 * 여러 인용 자료를 모아서 참고문헌 목록으로 저장
 */
export const bibliographies = mysqlTable("bibliographies", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  /** 참고문헌 목록 이름 */
  name: varchar("name", { length: 255 }).notNull(),
  /** 인용 형식: korean, apa, mla, chicago, krfoundation */
  format: mysqlEnum("format", ["korean", "apa", "mla", "chicago", "krfoundation"]).default("korean").notNull(),
  /** 포함된 인용 자료 ID 목록 (JSON 배열) */
  citationIds: json("citationIds").$type<number[]>().default([]).notNull(),
  /** 생성된 참고문헌 전체 텍스트 */
  content: text("content"),
  /** 생성 시간 */
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Bibliography = typeof bibliographies.$inferSelect;
export type InsertBibliography = typeof bibliographies.$inferInsert;

/**
 * 관계 정의
 */
export const usersRelations = relations(users, ({ many }) => ({
  citations: many(citations),
  templateDownloads: many(templateDownloads),
  bibliographies: many(bibliographies),
}));

export const citationsRelations = relations(citations, ({ one }) => ({
  user: one(users, {
    fields: [citations.userId],
    references: [users.id],
  }),
}));

export const bibliographiesRelations = relations(bibliographies, ({ one }) => ({
  user: one(users, {
    fields: [bibliographies.userId],
    references: [users.id],
  }),
}));