/*
 * Check.tsx - 논문 형식 검사 페이지 (2차 기능, 준비 중)
 * Design: Clean Scholar - Coming soon placeholder with feature preview
 */

import { ChevronRight, CheckSquare, Upload, FileSearch, AlertCircle, Clock } from "lucide-react";
import { Badge } from "@/components/ui/badge";

const plannedFeatures = [
  { icon: Upload, title: ".docx 파일 업로드", desc: "작성한 논문 파일을 업로드하면 자동으로 분석합니다." },
  { icon: FileSearch, title: "여백·글꼴·줄간격 검사", desc: "설정된 기준과 비교하여 형식 오류를 찾아냅니다." },
  { icon: AlertCircle, title: "제목 번호 체계 검사", desc: "장·절·항의 번호 체계가 올바른지 확인합니다." },
  { icon: CheckSquare, title: "각주·참고문헌 누락 검사", desc: "본문 인용과 참고문헌 목록의 일치 여부를 검사합니다." },
];

export default function Check() {
  return (
    <div className="min-h-screen bg-background">
      {/* Page Header */}
      <div className="border-b border-border bg-white">
        <div className="container py-8">
          <div className="flex items-center gap-2 text-sm text-muted-foreground mb-3">
            <span>홈</span>
            <ChevronRight size={14} />
            <span style={{ color: "var(--brand-indigo)" }}>형식 검사</span>
          </div>
          <div className="flex items-center gap-3">
            <h1
              className="text-3xl font-bold"
              style={{ fontFamily: "'Noto Serif KR', serif", color: "var(--brand-indigo)" }}
            >
              논문 형식 검사
            </h1>
            <Badge className="bg-amber-100 text-amber-700 border-0">준비 중</Badge>
          </div>
          <p className="text-muted-foreground mt-2">
            .docx 파일을 업로드하면 형식 오류를 자동으로 검사해 드립니다.
          </p>
        </div>
      </div>

      <div className="container py-12">
        {/* Coming Soon Card */}
        <div className="max-w-2xl mx-auto">
          <div className="bg-white rounded-xl border border-border p-8 text-center mb-8">
            <div
              className="w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4"
              style={{ backgroundColor: "oklch(0.28 0.08 240 / 0.08)" }}
            >
              <Clock size={28} style={{ color: "var(--brand-indigo)" }} />
            </div>
            <h2
              className="text-xl font-bold mb-3"
              style={{ fontFamily: "'Noto Serif KR', serif", color: "var(--brand-indigo)" }}
            >
              현재 개발 중인 기능입니다
            </h2>
            <p className="text-muted-foreground text-sm leading-relaxed">
              논문 형식 검사 기능은 현재 개발 중입니다. 완성되면 .docx 파일을 업로드하여
              여백, 글꼴, 줄간격, 제목 번호 체계, 각주·참고문헌 누락 여부를 자동으로
              검사할 수 있게 됩니다.
            </p>
          </div>

          {/* Planned Features */}
          <h3
            className="text-lg font-bold mb-4"
            style={{ fontFamily: "'Noto Serif KR', serif", color: "var(--brand-indigo)" }}
          >
            예정된 기능
          </h3>
          <div className="space-y-3 animate-stagger">
            {plannedFeatures.map(({ icon: Icon, title, desc }) => (
              <div
                key={title}
                className="flex items-start gap-4 p-4 bg-white rounded-lg border border-border opacity-70"
              >
                <div
                  className="w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0"
                  style={{ backgroundColor: "oklch(0.28 0.08 240 / 0.08)" }}
                >
                  <Icon size={16} className="text-primary" />
                </div>
                <div>
                  <p className="font-semibold text-sm text-foreground">{title}</p>
                  <p className="text-sm text-muted-foreground mt-0.5">{desc}</p>
                </div>
                <Badge variant="outline" className="flex-shrink-0 text-xs ml-auto">
                  준비 중
                </Badge>
              </div>
            ))}
          </div>

          {/* Alternative */}
          <div
            className="mt-8 p-5 rounded-xl border"
            style={{
              backgroundColor: "oklch(0.65 0.15 60 / 0.05)",
              borderColor: "oklch(0.65 0.15 60 / 0.3)",
            }}
          >
            <p className="text-sm font-semibold text-amber-700 mb-1">
              지금 바로 사용할 수 있는 기능
            </p>
            <p className="text-sm text-muted-foreground">
              인용 생성기와 템플릿을 활용하면 처음부터 올바른 형식으로 논문을 작성할 수 있습니다.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
