/*
 * Guide.tsx - 논문 작성 가이드 페이지
 * Design: Clean Scholar - Left sidebar index + right main content
 * Noto Serif KR headings, section tabs, step badges
 */

import { useState, useRef, useEffect } from "react";
import { BookOpen, ChevronRight, FileText, Lightbulb, Search, BookMarked, List } from "lucide-react";
import { cn } from "@/lib/utils";

interface Section {
  id: string;
  title: string;
  icon: React.ComponentType<{ size?: number; className?: string }>;
  content: React.ReactNode;
}

const TipBox = ({ children }: { children: React.ReactNode }) => (
  <div className="flex gap-3 p-4 rounded-lg bg-amber-50 border border-amber-200 my-4">
    <Lightbulb size={16} className="text-amber-600 flex-shrink-0 mt-0.5" />
    <p className="text-sm text-amber-800 leading-relaxed">{children}</p>
  </div>
);

const StepItem = ({ num, title, desc }: { num: number; title: string; desc: string }) => (
  <div className="flex gap-4 py-3">
    <div className="step-badge flex-shrink-0">{num}</div>
    <div>
      <p className="font-semibold text-foreground text-sm">{title}</p>
      <p className="text-sm text-muted-foreground mt-0.5 leading-relaxed">{desc}</p>
    </div>
  </div>
);

const SectionBlock = ({ title, children }: { title: string; children: React.ReactNode }) => (
  <div className="mb-8">
    <h3
      className="text-lg font-bold mb-3 pb-2 border-b border-border"
      style={{ fontFamily: "'Noto Serif KR', serif", color: "var(--brand-indigo)" }}
    >
      {title}
    </h3>
    <div className="space-y-3 text-sm text-foreground leading-7">{children}</div>
  </div>
);

const sections: Section[] = [
  {
    id: "structure",
    title: "논문 구성",
    icon: List,
    content: (
      <div>
        <SectionBlock title="학술 논문의 기본 구조">
          <p>
            학술 논문은 일반적으로 <strong>표지 → 목차 → 초록 → 서론 → 본론 → 결론 → 참고문헌</strong>의
            순서로 구성됩니다. 각 부분은 독립적이면서도 유기적으로 연결되어야 합니다.
          </p>
          <div className="mt-4 space-y-1">
            {[
              { num: 1, title: "표지 (Title Page)", desc: "논문 제목, 저자명, 소속 기관, 제출일 등을 포함합니다." },
              { num: 2, title: "목차 (Table of Contents)", desc: "각 섹션의 제목과 페이지 번호를 체계적으로 나열합니다." },
              { num: 3, title: "초록 (Abstract)", desc: "연구의 목적, 방법, 결과, 결론을 200~300자 내외로 요약합니다." },
              { num: 4, title: "서론 (Introduction)", desc: "연구 배경, 문제 제기, 연구 목적 및 범위를 서술합니다." },
              { num: 5, title: "본론 (Main Body)", desc: "이론적 배경, 연구 방법, 분석 결과를 체계적으로 서술합니다." },
              { num: 6, title: "결론 (Conclusion)", desc: "연구 결과를 종합하고 시사점 및 한계를 제시합니다." },
              { num: 7, title: "참고문헌 (References)", desc: "본문에서 인용한 모든 자료를 규정된 형식으로 나열합니다." },
            ].map((item) => (
              <StepItem key={item.num} {...item} />
            ))}
          </div>
          <TipBox>
            졸업 논문의 경우 학교마다 요구하는 구성이 다를 수 있습니다. 반드시 지도 교수님 또는
            학과 사무실에서 제공하는 논문 작성 지침을 먼저 확인하세요.
          </TipBox>
        </SectionBlock>

        <SectionBlock title="제목 번호 체계">
          <p>본론의 장·절·항은 일관된 번호 체계를 사용해야 합니다.</p>
          <div className="mt-3 p-4 rounded-lg bg-muted font-mono text-sm space-y-1">
            <p className="font-semibold">Ⅰ. 서론</p>
            <p className="pl-4">1. 연구 배경 및 목적</p>
            <p className="pl-8">1) 연구의 필요성</p>
            <p className="pl-12">(1) 사회적 배경</p>
            <p className="pl-4 mt-2">2. 연구 범위 및 방법</p>
            <p className="font-semibold mt-2">Ⅱ. 이론적 배경</p>
          </div>
          <TipBox>
            한국어 논문에서는 로마 숫자(Ⅰ, Ⅱ, Ⅲ)로 장을 구분하고, 아라비아 숫자(1, 2, 3)로
            절을, 한글 번호(1), 2))로 항을 구분하는 방식이 일반적입니다.
          </TipBox>
        </SectionBlock>
      </div>
    ),
  },
  {
    id: "abstract",
    title: "초록 작성법",
    icon: FileText,
    content: (
      <div>
        <SectionBlock title="초록(Abstract)이란?">
          <p>
            초록은 논문 전체를 압축한 요약문으로, 독자가 논문을 읽을지 결정하는 데 가장 중요한
            역할을 합니다. 일반적으로 <strong>200~300자(한국어)</strong> 또는{" "}
            <strong>150~250단어(영어)</strong> 내외로 작성합니다.
          </p>
        </SectionBlock>

        <SectionBlock title="초록의 4가지 핵심 요소">
          <div className="space-y-1">
            {[
              { num: 1, title: "연구 목적 (Purpose)", desc: "이 연구가 무엇을 밝히려 하는가?" },
              { num: 2, title: "연구 방법 (Method)", desc: "어떤 방법으로 연구를 수행했는가?" },
              { num: 3, title: "연구 결과 (Results)", desc: "연구를 통해 무엇을 발견했는가?" },
              { num: 4, title: "결론 및 시사점 (Conclusion)", desc: "결과가 갖는 의미는 무엇인가?" },
            ].map((item) => (
              <StepItem key={item.num} {...item} />
            ))}
          </div>
        </SectionBlock>

        <SectionBlock title="초록 작성 예시">
          <div className="citation-preview">
            <p className="text-xs text-muted-foreground mb-2 font-sans">▼ 작성 예시</p>
            <p>
              본 연구는 대학생의 학업 스트레스가 학습 몰입도에 미치는 영향을 분석하고, 사회적
              지지의 조절 효과를 검증하는 것을 목적으로 한다. 이를 위해 서울 소재 4년제 대학교
              재학생 300명을 대상으로 설문 조사를 실시하였으며, 위계적 회귀분석을 통해 자료를
              분석하였다. 분석 결과, 학업 스트레스는 학습 몰입도에 부적 영향을 미치는 것으로
              나타났으며, 사회적 지지는 이 관계를 유의미하게 조절하는 것으로 확인되었다. 본
              연구는 대학생의 학습 환경 개선을 위한 정책적 시사점을 제공한다.
            </p>
          </div>
          <TipBox>
            초록에는 본문에서 다루지 않은 내용을 포함하거나, 인용·각주를 사용하지 않습니다.
            완성된 논문을 기반으로 마지막에 작성하는 것이 효율적입니다.
          </TipBox>
        </SectionBlock>
      </div>
    ),
  },
  {
    id: "introduction",
    title: "서론 작성법",
    icon: BookOpen,
    content: (
      <div>
        <SectionBlock title="서론의 역할">
          <p>
            서론은 독자를 연구 주제로 안내하는 관문입니다. 연구의 필요성을 설득하고, 연구
            목적과 범위를 명확히 제시해야 합니다.
          </p>
        </SectionBlock>

        <SectionBlock title="서론 작성 순서">
          <div className="space-y-1">
            {[
              {
                num: 1,
                title: "연구 배경 제시",
                desc: "해당 주제가 왜 중요한지 사회적·학문적 맥락을 설명합니다.",
              },
              {
                num: 2,
                title: "선행 연구 검토",
                desc: "기존 연구의 성과와 한계를 간략히 정리하여 연구의 필요성을 부각합니다.",
              },
              {
                num: 3,
                title: "연구 목적 및 문제 제기",
                desc: "본 연구가 해결하려는 구체적인 연구 문제나 가설을 명시합니다.",
              },
              {
                num: 4,
                title: "연구 범위 및 방법 개요",
                desc: "연구 대상, 기간, 방법을 간략히 소개합니다.",
              },
              {
                num: 5,
                title: "논문 구성 안내",
                desc: "각 장에서 다룰 내용을 간략히 소개하여 독자의 이해를 돕습니다.",
              },
            ].map((item) => (
              <StepItem key={item.num} {...item} />
            ))}
          </div>
          <TipBox>
            서론의 길이는 전체 논문의 10~15% 정도가 적절합니다. 너무 길면 독자의 집중력을
            잃게 되고, 너무 짧으면 연구의 맥락을 이해하기 어렵습니다.
          </TipBox>
        </SectionBlock>

        <SectionBlock title="자주 하는 실수">
          <div className="space-y-2">
            {[
              "결론에서 다룰 내용을 서론에서 미리 언급하는 것",
              "연구 목적이 모호하거나 지나치게 광범위한 것",
              "선행 연구를 단순 나열하고 비판적 검토 없이 끝내는 것",
              "연구 문제와 연구 목적을 혼동하는 것",
            ].map((mistake, i) => (
              <div key={i} className="flex gap-2 items-start">
                <span className="text-red-500 font-bold text-sm flex-shrink-0 mt-0.5">✗</span>
                <p className="text-sm text-foreground">{mistake}</p>
              </div>
            ))}
          </div>
        </SectionBlock>
      </div>
    ),
  },
  {
    id: "methodology",
    title: "연구방법 작성법",
    icon: Search,
    content: (
      <div>
        <SectionBlock title="연구방법 섹션의 목적">
          <p>
            연구방법 섹션은 연구의 <strong>재현 가능성(reproducibility)</strong>을 보장합니다.
            다른 연구자가 동일한 방법으로 연구를 반복할 수 있을 만큼 구체적으로 서술해야 합니다.
          </p>
        </SectionBlock>

        <SectionBlock title="연구방법의 주요 구성 요소">
          <div className="grid gap-3">
            {[
              {
                title: "연구 설계 (Research Design)",
                desc: "양적 연구, 질적 연구, 혼합 연구 방법 중 선택한 이유를 설명합니다.",
              },
              {
                title: "연구 대상 (Participants/Sample)",
                desc: "연구 참여자의 특성, 표본 크기, 표집 방법을 구체적으로 기술합니다.",
              },
              {
                title: "측정 도구 (Instruments)",
                desc: "설문지, 인터뷰 가이드, 실험 장비 등 사용한 도구의 출처와 신뢰도를 제시합니다.",
              },
              {
                title: "자료 수집 절차 (Data Collection)",
                desc: "언제, 어디서, 어떻게 자료를 수집했는지 상세히 기술합니다.",
              },
              {
                title: "자료 분석 방법 (Data Analysis)",
                desc: "사용한 통계 기법이나 분석 소프트웨어(SPSS, R, NVivo 등)를 명시합니다.",
              },
            ].map((item, i) => (
              <div key={i} className="p-3 rounded-lg border border-border bg-card">
                <p className="font-semibold text-sm" style={{ color: "var(--brand-indigo)" }}>
                  {item.title}
                </p>
                <p className="text-sm text-muted-foreground mt-1">{item.desc}</p>
              </div>
            ))}
          </div>
          <TipBox>
            윤리적 고려 사항(IRB 승인, 동의서 취득 여부 등)도 연구방법 섹션에 포함하는 것이
            학술 논문의 기본 요건입니다.
          </TipBox>
        </SectionBlock>
      </div>
    ),
  },
  {
    id: "references",
    title: "참고문헌 작성법",
    icon: BookMarked,
    content: (
      <div>
        <SectionBlock title="참고문헌 작성의 기본 원칙">
          <p>
            참고문헌은 본문에서 인용하거나 참조한 모든 자료를 규정된 형식으로 나열한 목록입니다.
            학문적 정직성과 저작권 존중의 기본입니다.
          </p>
          <div className="mt-3 space-y-2">
            {[
              "본문에서 인용한 자료는 반드시 참고문헌에 포함해야 합니다.",
              "참고문헌에 있는 자료는 반드시 본문에서 인용되어야 합니다.",
              "저자명 기준으로 가나다순(한글) 또는 알파벳순(영문)으로 정렬합니다.",
              "한글 문헌을 먼저, 영문 문헌을 나중에 배치하는 것이 일반적입니다.",
            ].map((rule, i) => (
              <div key={i} className="flex gap-2 items-start">
                <span
                  className="font-bold text-sm flex-shrink-0 mt-0.5"
                  style={{ color: "var(--brand-indigo)" }}
                >
                  ✓
                </span>
                <p className="text-sm text-foreground">{rule}</p>
              </div>
            ))}
          </div>
        </SectionBlock>

        <SectionBlock title="주요 인용 형식 비교">
          <div className="overflow-x-auto">
            <table className="w-full text-sm border-collapse">
              <thead>
                <tr className="border-b-2 border-border">
                  <th
                    className="text-left py-2 pr-4 font-semibold"
                    style={{ color: "var(--brand-indigo)" }}
                  >
                    형식
                  </th>
                  <th className="text-left py-2 pr-4 font-semibold text-muted-foreground">
                    주요 사용 분야
                  </th>
                  <th className="text-left py-2 font-semibold text-muted-foreground">특징</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {[
                  { fmt: "APA 7판", field: "사회과학, 교육학, 심리학", feature: "저자-연도 방식" },
                  { fmt: "MLA 9판", field: "인문학, 문학, 언어학", feature: "저자-페이지 방식" },
                  { fmt: "Chicago 17판", field: "역사학, 예술, 인문학", feature: "각주 또는 저자-날짜" },
                  { fmt: "한국연구재단", field: "한국 학술지 전반", feature: "한국식 각주 + 참고문헌" },
                ].map((row, i) => (
                  <tr key={i}>
                    <td className="py-2 pr-4 font-medium">{row.fmt}</td>
                    <td className="py-2 pr-4 text-muted-foreground">{row.field}</td>
                    <td className="py-2 text-muted-foreground">{row.feature}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <TipBox>
            어떤 인용 형식을 사용할지 모를 때는 지도 교수님이나 투고 학술지의 투고 규정을
            먼저 확인하세요. 인용 형식은 논문 전체에서 일관되게 적용해야 합니다.
          </TipBox>
        </SectionBlock>

        <SectionBlock title="한국식 각주 형식 예시">
          <div className="space-y-3">
            {[
              {
                type: "단행본",
                example: "홍길동, 『논문 작성의 기초』, 서울: ○○출판사, 2024, 15쪽.",
              },
              {
                type: "학술 논문",
                example:
                  "김철수, 「대학생의 학업 스트레스 연구」, 『한국교육학연구』 30권 2호, 2023, 45-67쪽.",
              },
              {
                type: "인터넷 기사",
                example:
                  "이영희, 「논문 작성 지원 서비스 확대」, ○○일보, 2024.03.15, https://example.com (접속일: 2024.04.01).",
              },
            ].map((item, i) => (
              <div key={i}>
                <p className="text-xs font-semibold text-muted-foreground mb-1">{item.type}</p>
                <div className="citation-preview">{item.example}</div>
              </div>
            ))}
          </div>
        </SectionBlock>
      </div>
    ),
  },
];

export default function Guide() {
  const [activeSection, setActiveSection] = useState("structure");
  const contentRef = useRef<HTMLDivElement>(null);

  const currentSection = sections.find((s) => s.id === activeSection);

  return (
    <div className="min-h-screen bg-background">
      {/* Page Header */}
      <div className="border-b border-border bg-white">
        <div className="container py-8">
          <div className="flex items-center gap-2 text-sm text-muted-foreground mb-3">
            <span>홈</span>
            <ChevronRight size={14} />
            <span style={{ color: "var(--brand-indigo)" }}>작성 가이드</span>
          </div>
          <h1
            className="text-3xl font-bold mb-2"
            style={{ fontFamily: "'Noto Serif KR', serif", color: "var(--brand-indigo)" }}
          >
            논문 작성 가이드
          </h1>
          <p className="text-muted-foreground">
            논문 구성부터 참고문헌 작성까지, 단계별로 안내해 드립니다.
          </p>
        </div>
      </div>

      {/* Content */}
      <div className="container py-8">
        <div className="flex gap-8">
          {/* Sidebar */}
          <aside className="hidden lg:block w-56 flex-shrink-0">
            <div className="sticky top-24">
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3">
                목차
              </p>
              <nav className="space-y-1">
                {sections.map(({ id, title, icon: Icon }) => (
                  <button
                    key={id}
                    onClick={() => {
                      setActiveSection(id);
                      contentRef.current?.scrollTo({ top: 0 });
                    }}
                    className={cn(
                      "w-full flex items-center gap-2.5 px-3 py-2.5 rounded-md text-sm text-left transition-all duration-150",
                      activeSection === id
                        ? "font-semibold text-white"
                        : "text-muted-foreground hover:text-foreground hover:bg-muted"
                    )}
                    style={
                      activeSection === id ? { backgroundColor: "var(--brand-indigo)" } : {}
                    }
                  >
                    <Icon size={15} />
                    {title}
                  </button>
                ))}
              </nav>
            </div>
          </aside>

          {/* Mobile section tabs */}
          <div className="lg:hidden w-full mb-6">
            <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
              {sections.map(({ id, title, icon: Icon }) => (
                <button
                  key={id}
                  onClick={() => setActiveSection(id)}
                  className={cn(
                    "flex-shrink-0 flex items-center gap-1.5 px-3 py-2 rounded-full text-sm font-medium transition-all",
                    activeSection === id
                      ? "text-white"
                      : "text-muted-foreground bg-muted hover:bg-muted/80"
                  )}
                  style={activeSection === id ? { backgroundColor: "var(--brand-indigo)" } : {}}
                >
                  <Icon size={14} />
                  {title}
                </button>
              ))}
            </div>
          </div>

          {/* Main content */}
          <div ref={contentRef} className="flex-1 min-w-0">
            <div className="bg-white rounded-xl border border-border p-6 lg:p-8">
              {currentSection && (
                <div className="page-enter">
                  <div className="flex items-center gap-3 mb-6 pb-4 border-b border-border">
                    <div
                      className="w-10 h-10 rounded-lg flex items-center justify-center"
                      style={{ backgroundColor: "oklch(0.28 0.08 240 / 0.1)" }}
                    >
                      <currentSection.icon
                        size={20}
                        className="text-primary"
                      />
                    </div>
                    <h2
                      className="text-xl font-bold"
                      style={{
                        fontFamily: "'Noto Serif KR', serif",
                        color: "var(--brand-indigo)",
                      }}
                    >
                      {currentSection.title}
                    </h2>
                  </div>
                  {currentSection.content}
                </div>
              )}
            </div>

            {/* Navigation between sections */}
            <div className="flex justify-between mt-4">
              {sections.findIndex((s) => s.id === activeSection) > 0 && (
                <button
                  onClick={() => {
                    const idx = sections.findIndex((s) => s.id === activeSection);
                    setActiveSection(sections[idx - 1].id);
                  }}
                  className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors"
                >
                  ← 이전: {sections[sections.findIndex((s) => s.id === activeSection) - 1]?.title}
                </button>
              )}
              <div className="ml-auto">
                {sections.findIndex((s) => s.id === activeSection) < sections.length - 1 && (
                  <button
                    onClick={() => {
                      const idx = sections.findIndex((s) => s.id === activeSection);
                      setActiveSection(sections[idx + 1].id);
                    }}
                    className="flex items-center gap-2 text-sm font-medium transition-colors"
                    style={{ color: "var(--brand-indigo)" }}
                  >
                    다음: {sections[sections.findIndex((s) => s.id === activeSection) + 1]?.title}{" "}
                    →
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
