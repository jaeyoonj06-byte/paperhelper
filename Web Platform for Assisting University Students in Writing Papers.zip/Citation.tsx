/*
 * Citation.tsx - 각주·참고문헌 생성기 페이지
 * Design: Clean Scholar - Step-based form with live preview
 * Features: 자료 유형별 입력, 한국식 각주, APA/MLA/Chicago/한국연구재단 변환, 목록 관리
 */

import { useState, useCallback } from "react";
import { nanoid } from "nanoid";
import { toast } from "sonner";
import {
  BookOpen,
  FileText,
  Globe,
  Plus,
  Copy,
  Trash2,
  ChevronRight,
  Download,
  ArrowUpDown,
  Check,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { saveAs } from "file-saver";
import { Document, Packer, Paragraph, TextRun } from "docx";

// ─── Types ──────────────────────────────────────────────────────────────────

type SourceType = "book" | "journal" | "article";
type CitationStyle = "korean" | "apa" | "mla" | "chicago";

interface BookSource {
  id: string;
  type: "book";
  author: string;
  title: string;
  place: string;
  publisher: string;
  year: string;
  page: string;
}

interface JournalSource {
  id: string;
  type: "journal";
  author: string;
  title: string;
  journal: string;
  volume: string;
  issue: string;
  year: string;
  pages: string;
}

interface ArticleSource {
  id: string;
  type: "article";
  author: string;
  title: string;
  url: string;
  year: string;
  publishDate: string;
  accessDate: string;
}

type Source = BookSource | JournalSource | ArticleSource;

// ─── Citation Formatters ─────────────────────────────────────────────────────

function formatKoreanFootnote(source: Source): string {
  if (source.type === "book") {
    const { author, title, place, publisher, year, page } = source;
    const pageStr = page ? `, ${page}쪽` : "";
    return `${author || "저자 미상"}, 『${title || "제목 없음"}』, ${place || "출판지 미상"}: ${publisher || "출판사 미상"}, ${year || "연도 미상"}${pageStr}.`;
  }
  if (source.type === "journal") {
    const { author, title, journal, volume, issue, year, pages } = source;
    const volIssue = volume && issue ? ` ${volume}권 ${issue}호` : volume ? ` ${volume}권` : "";
    const pageStr = pages ? `, ${pages}쪽` : "";
    return `${author || "저자 미상"}, 「${title || "제목 없음"}」, 『${journal || "게재지 미상"}』${volIssue}, ${year || "연도 미상"}${pageStr}.`;
  }
  if (source.type === "article") {
    const { author, title, url, publishDate, accessDate } = source;
    const authorStr = author ? `${author}, ` : "";
    const accessStr = accessDate ? ` (접속일: ${accessDate})` : "";
    return `${authorStr}「${title || "제목 없음"}」, ${publishDate || "날짜 미상"}, ${url || "URL 미상"}${accessStr}.`;
  }
  return "";
}

function formatAPA(source: Source): string {
  if (source.type === "book") {
    const { author, year, title, place, publisher } = source;
    return `${author || "저자 미상"}. (${year || "n.d."}). *${title || "제목 없음"}*. ${publisher || "출판사 미상"}.`;
  }
  if (source.type === "journal") {
    const { author, year, title, journal, volume, issue, pages } = source;
    const issueStr = issue ? `(${issue})` : "";
    const pageStr = pages ? `, ${pages}` : "";
    return `${author || "저자 미상"}. (${year || "n.d."}). ${title || "제목 없음"}. *${journal || "게재지 미상"}*, *${volume || "?"}*${issueStr}${pageStr}.`;
  }
  if (source.type === "article") {
    const { author, year, title, url, accessDate } = source;
    const authorStr = author || "저자 미상";
    const accessStr = accessDate ? ` Retrieved ${accessDate}, from` : "";
    return `${authorStr}. (${year || "n.d."}). ${title || "제목 없음"}.${accessStr} ${url || "URL 미상"}`;
  }
  return "";
}

function formatMLA(source: Source): string {
  if (source.type === "book") {
    const { author, title, publisher, year } = source;
    return `${author || "저자 미상"}. *${title || "제목 없음"}*. ${publisher || "출판사 미상"}, ${year || "n.d."}`;
  }
  if (source.type === "journal") {
    const { author, title, journal, volume, issue, year, pages } = source;
    const volIssue = volume && issue ? `vol. ${volume}, no. ${issue}` : volume ? `vol. ${volume}` : "";
    const pageStr = pages ? `, pp. ${pages}` : "";
    return `${author || "저자 미상"}. "${title || "제목 없음"}." *${journal || "게재지 미상"}*, ${volIssue}, ${year || "n.d."}${pageStr}.`;
  }
  if (source.type === "article") {
    const { author, title, url, publishDate, accessDate } = source;
    const authorStr = author ? `${author}. ` : "";
    const accessStr = accessDate ? ` Accessed ${accessDate}.` : "";
    return `${authorStr}"${title || "제목 없음"}." ${publishDate || "n.d."}, ${url || "URL 미상"}.${accessStr}`;
  }
  return "";
}

function formatChicago(source: Source): string {
  if (source.type === "book") {
    const { author, title, place, publisher, year } = source;
    return `${author || "저자 미상"}. *${title || "제목 없음"}*. ${place || "출판지 미상"}: ${publisher || "출판사 미상"}, ${year || "n.d."}.`;
  }
  if (source.type === "journal") {
    const { author, title, journal, volume, issue, year, pages } = source;
    const issueStr = issue ? `, no. ${issue}` : "";
    const pageStr = pages ? `: ${pages}` : "";
    return `${author || "저자 미상"}. "${title || "제목 없음"}." *${journal || "게재지 미상"}* ${volume || "?"}${issueStr} (${year || "n.d."})${pageStr}.`;
  }
  if (source.type === "article") {
    const { author, title, url, publishDate, accessDate } = source;
    const authorStr = author ? `${author}. ` : "";
    const accessStr = accessDate ? ` Accessed ${accessDate}.` : "";
    return `${authorStr}"${title || "제목 없음"}." ${publishDate || "n.d."}. ${url || "URL 미상"}.${accessStr}`;
  }
  return "";
}

function formatKoreanRef(source: Source): string {
  if (source.type === "book") {
    const { author, title, place, publisher, year } = source;
    return `${author || "저자 미상"}, 『${title || "제목 없음"}』, ${place || "출판지 미상"}: ${publisher || "출판사 미상"}, ${year || "연도 미상"}.`;
  }
  if (source.type === "journal") {
    const { author, title, journal, volume, issue, year, pages } = source;
    const volIssue = volume && issue ? ` ${volume}권 ${issue}호` : volume ? ` ${volume}권` : "";
    const pageStr = pages ? `, ${pages}쪽` : "";
    return `${author || "저자 미상"}, 「${title || "제목 없음"}」, 『${journal || "게재지 미상"}』${volIssue} (${year || "연도 미상"})${pageStr}.`;
  }
  if (source.type === "article") {
    const { author, title, url, publishDate, accessDate } = source;
    const authorStr = author ? `${author}, ` : "";
    const accessStr = accessDate ? ` (접속일: ${accessDate})` : "";
    return `${authorStr}「${title || "제목 없음"}」, ${publishDate || "날짜 미상"}, ${url || "URL 미상"}${accessStr}.`;
  }
  return "";
}

function formatSource(source: Source, style: CitationStyle): string {
  switch (style) {
    case "korean": return formatKoreanRef(source);
    case "apa": return formatAPA(source);
    case "mla": return formatMLA(source);
    case "chicago": return formatChicago(source);
  }
}

function getSortKey(source: Source): string {
  if (source.type === "book") return source.author;
  if (source.type === "journal") return source.author;
  return (source as ArticleSource).author || (source as ArticleSource).title;
}

// ─── Form Components ─────────────────────────────────────────────────────────

function FieldGroup({ label, hint, children }: { label: string; hint?: string; children: React.ReactNode }) {
  return (
    <div className="space-y-1.5">
      <Label className="text-sm font-medium text-foreground">{label}</Label>
      {hint && <p className="text-xs text-muted-foreground">{hint}</p>}
      {children}
    </div>
  );
}

// ─── Main Component ──────────────────────────────────────────────────────────

const defaultBook: Omit<BookSource, "id"> = {
  type: "book", author: "", title: "", place: "", publisher: "", year: "", page: "",
};
const defaultJournal: Omit<JournalSource, "id"> = {
  type: "journal", author: "", title: "", journal: "", volume: "", issue: "", year: "", pages: "",
};
const defaultArticle: Omit<ArticleSource, "id"> = {
  type: "article", author: "", title: "", url: "", year: "", publishDate: "", accessDate: "",
};

export default function Citation() {
  const [sourceType, setSourceType] = useState<SourceType>("book");
  const [bookForm, setBookForm] = useState<Omit<BookSource, "id">>(defaultBook);
  const [journalForm, setJournalForm] = useState<Omit<JournalSource, "id">>(defaultJournal);
  const [articleForm, setArticleForm] = useState<Omit<ArticleSource, "id">>(defaultArticle);
  const [sources, setSources] = useState<Source[]>([]);
  const [citationStyle, setCitationStyle] = useState<CitationStyle>("korean");
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const currentForm = sourceType === "book" ? bookForm : sourceType === "journal" ? journalForm : articleForm;

  const footnotePreview = (() => {
    const tempSource = { id: "preview", ...currentForm } as Source;
    return formatKoreanFootnote(tempSource);
  })();

  const addSource = useCallback(() => {
    const newSource = { id: nanoid(), ...currentForm } as Source;
    setSources((prev) => [...prev, newSource]);
    // Reset form
    if (sourceType === "book") setBookForm(defaultBook);
    else if (sourceType === "journal") setJournalForm(defaultJournal);
    else setArticleForm(defaultArticle);
    toast.success("자료가 목록에 추가되었습니다.");
  }, [currentForm, sourceType]);

  const removeSource = (id: string) => {
    setSources((prev) => prev.filter((s) => s.id !== id));
    toast.success("자료가 삭제되었습니다.");
  };

  const copyText = async (text: string, id: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedId(id);
      setTimeout(() => setCopiedId(null), 2000);
      toast.success("클립보드에 복사되었습니다.");
    } catch {
      toast.error("복사에 실패했습니다.");
    }
  };

  const sortedSources = [...sources].sort((a, b) => {
    const ka = getSortKey(a);
    const kb = getSortKey(b);
    return ka.localeCompare(kb, "ko");
  });

  const allReferences = sortedSources.map((s) => formatSource(s, citationStyle)).join("\n");

  const copyAll = () => copyText(allReferences, "all");

  const downloadTxt = () => {
    const blob = new Blob([allReferences], { type: "text/plain;charset=utf-8" });
    saveAs(blob, "참고문헌.txt");
  };

  const downloadDocx = async () => {
    const doc = new Document({
      sections: [{
        children: [
          new Paragraph({
            children: [new TextRun({ text: "참고문헌", bold: true, size: 28 })],
          }),
          new Paragraph({ children: [] }),
          ...sortedSources.map((s) =>
            new Paragraph({
              children: [new TextRun({ text: formatSource(s, citationStyle), size: 22 })],
              spacing: { after: 120 },
            })
          ),
        ],
      }],
    });
    const blob = await Packer.toBlob(doc);
    saveAs(blob, "참고문헌.docx");
  };

  const styleLabels: Record<CitationStyle, string> = {
    korean: "한국연구재단",
    apa: "APA 7판",
    mla: "MLA 9판",
    chicago: "Chicago 17판",
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Page Header */}
      <div className="border-b border-border bg-white">
        <div className="container py-8">
          <div className="flex items-center gap-2 text-sm text-muted-foreground mb-3">
            <span>홈</span>
            <ChevronRight size={14} />
            <span style={{ color: "var(--brand-indigo)" }}>인용 생성기</span>
          </div>
          <h1
            className="text-3xl font-bold mb-2"
            style={{ fontFamily: "'Noto Serif KR', serif", color: "var(--brand-indigo)" }}
          >
            각주·참고문헌 생성기
          </h1>
          <p className="text-muted-foreground">
            자료 정보를 입력하면 한국식 각주와 다양한 참고문헌 형식을 자동으로 생성합니다.
          </p>
        </div>
      </div>

      <div className="container py-8">
        <div className="grid lg:grid-cols-2 gap-8">
          {/* Left: Input Form */}
          <div className="space-y-6">
            {/* Step 1: Source Type */}
            <div className="bg-white rounded-xl border border-border p-6">
              <div className="flex items-center gap-3 mb-5">
                <div className="step-badge">1</div>
                <h2 className="font-semibold text-foreground">자료 유형 선택</h2>
              </div>
              <div className="grid grid-cols-3 gap-3">
                {([
                  { type: "book" as SourceType, label: "단행본", icon: BookOpen },
                  { type: "journal" as SourceType, label: "학술논문", icon: FileText },
                  { type: "article" as SourceType, label: "인터넷 기사", icon: Globe },
                ] as const).map(({ type, label, icon: Icon }) => (
                  <button
                    key={type}
                    onClick={() => setSourceType(type)}
                    className={cn(
                      "flex flex-col items-center gap-2 p-4 rounded-lg border-2 transition-all duration-150",
                      sourceType === type
                        ? "border-primary bg-primary/5"
                        : "border-border hover:border-primary/40 hover:bg-muted/50"
                    )}
                    style={
                      sourceType === type
                        ? { borderColor: "var(--brand-indigo)", backgroundColor: "oklch(0.28 0.08 240 / 0.05)" }
                        : {}
                    }
                  >
                    <Icon
                      size={20}
                      className={sourceType === type ? "text-primary" : "text-muted-foreground"}
                      style={sourceType === type ? { color: "var(--brand-indigo)" } : {}}
                    />
                    <span
                      className={cn(
                        "text-sm font-medium",
                        sourceType === type ? "text-primary" : "text-muted-foreground"
                      )}
                      style={sourceType === type ? { color: "var(--brand-indigo)" } : {}}
                    >
                      {label}
                    </span>
                  </button>
                ))}
              </div>
            </div>

            {/* Step 2: Input Fields */}
            <div className="bg-white rounded-xl border border-border p-6">
              <div className="flex items-center gap-3 mb-5">
                <div className="step-badge">2</div>
                <h2 className="font-semibold text-foreground">자료 정보 입력</h2>
              </div>

              {sourceType === "book" && (
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <FieldGroup label="저자" hint="예: 홍길동">
                      <Input
                        placeholder="저자명"
                        value={bookForm.author}
                        onChange={(e) => setBookForm((f) => ({ ...f, author: e.target.value }))}
                      />
                    </FieldGroup>
                    <FieldGroup label="발행연도" hint="예: 2024">
                      <Input
                        placeholder="연도"
                        value={bookForm.year}
                        onChange={(e) => setBookForm((f) => ({ ...f, year: e.target.value }))}
                      />
                    </FieldGroup>
                  </div>
                  <FieldGroup label="책 제목" hint="예: 논문 작성의 기초">
                    <Input
                      placeholder="책 제목"
                      value={bookForm.title}
                      onChange={(e) => setBookForm((f) => ({ ...f, title: e.target.value }))}
                    />
                  </FieldGroup>
                  <div className="grid grid-cols-2 gap-4">
                    <FieldGroup label="출판지" hint="예: 서울">
                      <Input
                        placeholder="출판지"
                        value={bookForm.place}
                        onChange={(e) => setBookForm((f) => ({ ...f, place: e.target.value }))}
                      />
                    </FieldGroup>
                    <FieldGroup label="출판사" hint="예: ○○출판사">
                      <Input
                        placeholder="출판사명"
                        value={bookForm.publisher}
                        onChange={(e) => setBookForm((f) => ({ ...f, publisher: e.target.value }))}
                      />
                    </FieldGroup>
                  </div>
                  <FieldGroup label="인용 페이지" hint="각주에 표시할 페이지 (예: 15)">
                    <Input
                      placeholder="페이지 번호"
                      value={bookForm.page}
                      onChange={(e) => setBookForm((f) => ({ ...f, page: e.target.value }))}
                    />
                  </FieldGroup>
                </div>
              )}

              {sourceType === "journal" && (
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <FieldGroup label="저자" hint="예: 김철수">
                      <Input
                        placeholder="저자명"
                        value={journalForm.author}
                        onChange={(e) => setJournalForm((f) => ({ ...f, author: e.target.value }))}
                      />
                    </FieldGroup>
                    <FieldGroup label="발행연도" hint="예: 2023">
                      <Input
                        placeholder="연도"
                        value={journalForm.year}
                        onChange={(e) => setJournalForm((f) => ({ ...f, year: e.target.value }))}
                      />
                    </FieldGroup>
                  </div>
                  <FieldGroup label="논문 제목" hint="예: 대학생의 학업 스트레스 연구">
                    <Input
                      placeholder="논문 제목"
                      value={journalForm.title}
                      onChange={(e) => setJournalForm((f) => ({ ...f, title: e.target.value }))}
                    />
                  </FieldGroup>
                  <FieldGroup label="게재지명" hint="예: 한국교육학연구">
                    <Input
                      placeholder="학술지명"
                      value={journalForm.journal}
                      onChange={(e) => setJournalForm((f) => ({ ...f, journal: e.target.value }))}
                    />
                  </FieldGroup>
                  <div className="grid grid-cols-3 gap-4">
                    <FieldGroup label="권(Volume)" hint="예: 30">
                      <Input
                        placeholder="권"
                        value={journalForm.volume}
                        onChange={(e) => setJournalForm((f) => ({ ...f, volume: e.target.value }))}
                      />
                    </FieldGroup>
                    <FieldGroup label="호(Issue)" hint="예: 2">
                      <Input
                        placeholder="호"
                        value={journalForm.issue}
                        onChange={(e) => setJournalForm((f) => ({ ...f, issue: e.target.value }))}
                      />
                    </FieldGroup>
                    <FieldGroup label="페이지" hint="예: 45-67">
                      <Input
                        placeholder="시작-끝"
                        value={journalForm.pages}
                        onChange={(e) => setJournalForm((f) => ({ ...f, pages: e.target.value }))}
                      />
                    </FieldGroup>
                  </div>
                </div>
              )}

              {sourceType === "article" && (
                <div className="space-y-4">
                  <FieldGroup label="저자 (선택)" hint="작성자가 있는 경우 입력">
                    <Input
                      placeholder="저자명 (없으면 비워두세요)"
                      value={articleForm.author}
                      onChange={(e) => setArticleForm((f) => ({ ...f, author: e.target.value }))}
                    />
                  </FieldGroup>
                  <FieldGroup label="기사 제목" hint="예: 논문 작성 지원 서비스 확대">
                    <Input
                      placeholder="기사 제목"
                      value={articleForm.title}
                      onChange={(e) => setArticleForm((f) => ({ ...f, title: e.target.value }))}
                    />
                  </FieldGroup>
                  <FieldGroup label="URL" hint="기사의 전체 웹 주소">
                    <Input
                      placeholder="https://..."
                      value={articleForm.url}
                      onChange={(e) => setArticleForm((f) => ({ ...f, url: e.target.value }))}
                    />
                  </FieldGroup>
                  <div className="grid grid-cols-2 gap-4">
                    <FieldGroup label="발행일" hint="예: 2024.03.15">
                      <Input
                        placeholder="발행 날짜"
                        value={articleForm.publishDate}
                        onChange={(e) => setArticleForm((f) => ({ ...f, publishDate: e.target.value }))}
                      />
                    </FieldGroup>
                    <FieldGroup label="접속일" hint="예: 2024.04.01">
                      <Input
                        placeholder="접속 날짜"
                        value={articleForm.accessDate}
                        onChange={(e) => setArticleForm((f) => ({ ...f, accessDate: e.target.value }))}
                      />
                    </FieldGroup>
                  </div>
                  <FieldGroup label="발행연도" hint="예: 2024 (APA 형식에서 사용)">
                    <Input
                      placeholder="연도"
                      value={articleForm.year}
                      onChange={(e) => setArticleForm((f) => ({ ...f, year: e.target.value }))}
                    />
                  </FieldGroup>
                  <div className="hidden">
                  </div>
                </div>
              )}
            </div>

            {/* Step 3: Preview & Add */}
            <div className="bg-white rounded-xl border border-border p-6">
              <div className="flex items-center gap-3 mb-4">
                <div className="step-badge">3</div>
                <h2 className="font-semibold text-foreground">한국식 각주 미리보기</h2>
              </div>
              <div className="citation-preview mb-4">{footnotePreview}</div>
              <div className="flex gap-3">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => copyText(footnotePreview, "footnote")}
                  className="gap-2"
                >
                  {copiedId === "footnote" ? <Check size={14} /> : <Copy size={14} />}
                  각주 복사
                </Button>
                <Button
                  size="sm"
                  onClick={addSource}
                  className="gap-2 ml-auto"
                  style={{ backgroundColor: "var(--brand-indigo)" }}
                >
                  <Plus size={14} />
                  목록에 추가
                </Button>
              </div>
            </div>
          </div>

          {/* Right: Reference List */}
          <div className="space-y-6">
            {/* Source List */}
            <div className="bg-white rounded-xl border border-border p-6">
              <div className="flex items-center justify-between mb-4">
                <h2 className="font-semibold text-foreground flex items-center gap-2">
                  입력한 자료 목록
                  {sources.length > 0 && (
                    <Badge variant="secondary" className="text-xs">
                      {sources.length}건
                    </Badge>
                  )}
                </h2>
                {sources.length > 1 && (
                  <span className="flex items-center gap-1 text-xs text-muted-foreground">
                    <ArrowUpDown size={12} />
                    가나다순 정렬
                  </span>
                )}
              </div>

              {sources.length === 0 ? (
                <div className="text-center py-10 text-muted-foreground">
                  <FileText size={32} className="mx-auto mb-3 opacity-30" />
                  <p className="text-sm">아직 추가된 자료가 없습니다.</p>
                  <p className="text-xs mt-1">왼쪽 폼에서 자료를 입력하고 추가하세요.</p>
                </div>
              ) : (
                <div className="space-y-2 max-h-64 overflow-y-auto">
                  {sortedSources.map((source) => (
                    <div
                      key={source.id}
                      className="flex items-start gap-3 p-3 rounded-lg bg-muted/50 group"
                    >
                      <div className="flex-shrink-0 mt-0.5">
                        {source.type === "book" ? (
                          <BookOpen size={14} className="text-muted-foreground" />
                        ) : source.type === "journal" ? (
                          <FileText size={14} className="text-muted-foreground" />
                        ) : (
                          <Globe size={14} className="text-muted-foreground" />
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium truncate">
                          {source.type === "book"
                            ? source.title || "제목 없음"
                            : source.type === "journal"
                            ? source.title || "제목 없음"
                            : (source as ArticleSource).title || "제목 없음"}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          {source.type === "book"
                            ? source.author
                            : source.type === "journal"
                            ? source.author
                            : (source as ArticleSource).author || "저자 미상"}
                        </p>
                      </div>
                      <button
                        onClick={() => removeSource(source.id)}
                        className="opacity-0 group-hover:opacity-100 transition-opacity p-1 hover:text-destructive"
                        aria-label="삭제"
                      >
                        <Trash2 size={14} />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Reference List Output */}
            <div className="bg-white rounded-xl border border-border p-6">
              <div className="flex items-center justify-between mb-4">
                <h2 className="font-semibold text-foreground">참고문헌 목록</h2>
                <Select
                  value={citationStyle}
                  onValueChange={(v) => setCitationStyle(v as CitationStyle)}
                >
                  <SelectTrigger className="w-40 text-sm h-8">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="korean">한국연구재단</SelectItem>
                    <SelectItem value="apa">APA 7판</SelectItem>
                    <SelectItem value="mla">MLA 9판</SelectItem>
                    <SelectItem value="chicago">Chicago 17판</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {sources.length === 0 ? (
                <div className="citation-preview text-muted-foreground text-sm">
                  자료를 추가하면 여기에 참고문헌 목록이 자동으로 생성됩니다.
                </div>
              ) : (
                <div className="citation-preview space-y-2">
                  {sortedSources.map((source, i) => (
                    <p key={source.id} className="leading-relaxed">
                      {formatSource(source, citationStyle)}
                    </p>
                  ))}
                </div>
              )}

              {sources.length > 0 && (
                <div className="flex flex-wrap gap-2 mt-4">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={copyAll}
                    className="gap-2"
                  >
                    {copiedId === "all" ? <Check size={14} /> : <Copy size={14} />}
                    전체 복사
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={downloadTxt}
                    className="gap-2"
                  >
                    <Download size={14} />
                    .txt 다운로드
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={downloadDocx}
                    className="gap-2"
                  >
                    <Download size={14} />
                    .docx 다운로드
                  </Button>
                </div>
              )}

              {sources.length > 0 && (
                <p className="text-xs text-muted-foreground mt-3">
                  현재 형식: <strong>{styleLabels[citationStyle]}</strong> · 저자명 기준 가나다순 정렬
                </p>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
