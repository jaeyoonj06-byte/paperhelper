/*
 * Home.tsx - 랜딩 페이지
 * Design: Clean Scholar - Asymmetric hero + feature cards + CTA
 * Deep Indigo hero with off-white sections, Noto Serif KR headings
 */

import { Link } from "wouter";
import { ArrowRight, BookOpen, Quote, Download, ChevronRight, Star } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/_core/hooks/useAuth";

const features = [
  {
    href: "/guide",
    icon: BookOpen,
    title: "논문 작성 가이드",
    desc: "논문 구성, 초록, 서론, 연구방법, 참고문헌 작성법을 단계별로 안내합니다.",
    color: "#1e3a5f",
    badge: null,
    cta: "가이드 보기",
  },
  {
    href: "/citation",
    icon: Quote,
    title: "자동 각주·인용 생성기",
    desc: "책, 논문, 기사 정보를 입력하면 한국식 각주와 APA/MLA/Chicago 형식을 자동 생성합니다.",
    color: "#d97706",
    badge: "핵심 기능",
    cta: "인용 만들기",
  },
  {
    href: "/templates",
    icon: Download,
    title: "논문 템플릿 다운로드",
    desc: "학술논문, 졸업논문, 보고서 형식이 적용된 .docx 파일을 무료로 다운로드하세요.",
    color: "#059669",
    badge: null,
    cta: "템플릿 받기",
  },

];

const steps = [
  {
    num: "01",
    title: "자료 정보 입력",
    desc: "책, 논문, 인터넷 기사 중 자료 유형을 선택하고 저자, 제목, 출판사 등 정보를 입력합니다.",
  },
  {
    num: "02",
    title: "형식 자동 생성",
    desc: "한국식 각주와 APA, MLA, Chicago, 한국연구재단 형식 중 원하는 양식을 선택합니다.",
  },
  {
    num: "03",
    title: "복사 또는 다운로드",
    desc: "생성된 각주를 클립보드에 복사하거나, 전체 참고문헌 목록을 .txt/.docx로 다운로드합니다.",
  },
];

const stats = [
  { value: "4가지", label: "인용 형식 지원" },
  { value: "3종", label: "논문 템플릿" },
  { value: "무료", label: "모든 기능 제공" },
  { value: "즉시", label: ".docx 다운로드" },
];

export default function Home() {
  const { user, loading } = useAuth();

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative overflow-hidden" style={{ backgroundColor: "var(--brand-indigo)" }}>
        {/* Background image */}
        <div
          className="absolute inset-0 opacity-30"
          style={{
            backgroundImage: `url(https://d2xsxph8kpxj0f.cloudfront.net/310519663762868322/CsRvtfedZ8KzkwHQEF6Zir/hero-bg-Vt3hCCTZw7KGtAyWU7X265.webp)`,
            backgroundSize: "cover",
            backgroundPosition: "center",
          }}
        />
        <div className="absolute inset-0" style={{ background: "linear-gradient(135deg, rgba(30,58,95,0.95) 0%, rgba(30,58,95,0.7) 100%)" }} />

        <div className="relative container py-20 lg:py-28">
          <div className="max-w-3xl">
            <Badge className="mb-6 bg-white/15 text-white border-white/20 hover:bg-white/20">
              <Star size={12} className="mr-1.5" />
              대학생을 위한 무료 논문 작성 도구
            </Badge>
            <h1
              className="text-4xl lg:text-5xl xl:text-6xl font-bold text-white leading-tight mb-6"
              style={{ fontFamily: "'Noto Serif KR', serif" }}
            >
              인용 형식,
              <br />
              <span style={{ color: "#fbbf24" }}>더 이상 헷갈리지</span>
              <br />
              마세요
            </h1>
            <p className="text-lg text-white/75 leading-relaxed mb-8 max-w-xl">
              논문 작성의 첫 단계부터 마지막까지. 자동 각주 생성, 참고문헌 변환, 논문 템플릿을
              한 곳에서 무료로 제공합니다.
            </p>
            <div className="flex flex-wrap gap-3">
              <Link href="/citation">
                <Button
                  size="lg"
                  className="gap-2 font-semibold"
                  style={{ backgroundColor: "#d97706", color: "white" }}
                >
                  각주 바로 만들기
                  <ArrowRight size={16} />
                </Button>
              </Link>
              <Link href="/guide">
                <Button
                  size="lg"
                  variant="outline"
                  className="gap-2 font-semibold border-white/30 text-white hover:bg-white/10"
                  style={{ backgroundColor: "transparent" }}
                >
                  <BookOpen size={16} />
                  작성 가이드 보기
                </Button>
              </Link>
            </div>
          </div>
        </div>

        {/* Stats bar */}
        <div className="relative border-t border-white/10">
          <div className="container py-5">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {stats.map(({ value, label }) => (
                <div key={label} className="text-center">
                  <p className="text-2xl font-bold text-white" style={{ fontFamily: "'Noto Serif KR', serif" }}>
                    {value}
                  </p>
                  <p className="text-sm text-white/60 mt-0.5">{label}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 lg:py-20 bg-background">
        <div className="container">
          <div className="text-center mb-12">
            <p
              className="text-sm font-semibold uppercase tracking-widest mb-3"
              style={{ color: "var(--brand-amber)" }}
            >
              핵심 기능
            </p>
            <h2
              className="text-3xl lg:text-4xl font-bold mb-4"
              style={{ fontFamily: "'Noto Serif KR', serif", color: "var(--brand-indigo)" }}
            >
              논문 작성의 모든 단계를 지원합니다
            </h2>
            <p className="text-muted-foreground max-w-xl mx-auto">
              형식 때문에 논문 작성에 시간을 낭비하지 마세요. 내용에만 집중할 수 있도록
              논문 도우미가 형식을 책임집니다.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-5 animate-stagger">
            {features.map(({ href, icon: Icon, title, desc, color, badge, cta }) => (
              <Link key={href} href={href}>
                <div className="group bg-white rounded-xl border border-border p-6 card-hover h-full flex flex-col">
                  <div className="flex items-start justify-between mb-4">
                    <div
                      className="w-11 h-11 rounded-lg flex items-center justify-center flex-shrink-0"
                      style={{ backgroundColor: `${color}12` }}
                    >
                      <Icon size={20} style={{ color }} />
                    </div>
                    {badge && (
                      <Badge
                        className={
                          badge === "준비 중"
                            ? "bg-amber-100 text-amber-700 border-0 text-xs"
                            : "bg-blue-100 text-blue-700 border-0 text-xs"
                        }
                      >
                        {badge}
                      </Badge>
                    )}
                  </div>
                  <h3
                    className="font-bold text-lg mb-2"
                    style={{ fontFamily: "'Noto Serif KR', serif", color: "var(--brand-indigo)" }}
                  >
                    {title}
                  </h3>
                  <p className="text-sm text-muted-foreground leading-relaxed flex-1">{desc}</p>
                  <div
                    className="flex items-center gap-1.5 mt-4 text-sm font-medium transition-all duration-150 group-hover:gap-2.5"
                    style={{ color }}
                  >
                    {cta}
                    <ChevronRight size={14} />
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* How it works */}
      <section className="py-16 lg:py-20" style={{ backgroundColor: "oklch(0.97 0.005 240)" }}>
        <div className="container">
          <div className="max-w-3xl mx-auto">
            <div className="text-center mb-12">
              <p
                className="text-sm font-semibold uppercase tracking-widest mb-3"
                style={{ color: "var(--brand-amber)" }}
              >
                사용 방법
              </p>
              <h2
                className="text-3xl font-bold mb-4"
                style={{ fontFamily: "'Noto Serif KR', serif", color: "var(--brand-indigo)" }}
              >
                3단계로 참고문헌 완성
              </h2>
            </div>

            <div className="space-y-4">
              {steps.map(({ num, title, desc }, i) => (
                <div
                  key={num}
                  className="flex gap-5 bg-white rounded-xl p-5 border border-border"
                  style={{ animationDelay: `${i * 80}ms` }}
                >
                  <div
                    className="w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0 font-bold text-lg"
                    style={{
                      backgroundColor: "var(--brand-indigo)",
                      color: "white",
                      fontFamily: "'Noto Serif KR', serif",
                    }}
                  >
                    {num}
                  </div>
                  <div>
                    <h3
                      className="font-bold text-base mb-1"
                      style={{ color: "var(--brand-indigo)" }}
                    >
                      {title}
                    </h3>
                    <p className="text-sm text-muted-foreground leading-relaxed">{desc}</p>
                  </div>
                </div>
              ))}
            </div>

            <div className="text-center mt-8">
              <Link href="/citation">
                <Button
                  size="lg"
                  className="gap-2"
                  style={{ backgroundColor: "var(--brand-indigo)" }}
                >
                  지금 바로 시작하기
                  <ArrowRight size={16} />
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Citation Preview Section */}
      <section className="py-16 lg:py-20 bg-white">
        <div className="container">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <p
                className="text-sm font-semibold uppercase tracking-widest mb-3"
                style={{ color: "var(--brand-amber)" }}
              >
                자동 생성 예시
              </p>
              <h2
                className="text-3xl font-bold mb-4"
                style={{ fontFamily: "'Noto Serif KR', serif", color: "var(--brand-indigo)" }}
              >
                이렇게 자동으로
                <br />
                만들어 드립니다
              </h2>
              <p className="text-muted-foreground leading-relaxed mb-6">
                저자, 제목, 출판사 등 기본 정보만 입력하면 한국식 각주부터 APA, MLA, Chicago,
                한국연구재단 형식까지 즉시 변환해 드립니다.
              </p>
              <Link href="/citation">
                <Button className="gap-2" style={{ backgroundColor: "var(--brand-indigo)" }}>
                  직접 해보기
                  <ArrowRight size={16} />
                </Button>
              </Link>
            </div>

            <div className="space-y-3">
              {[
                {
                  label: "한국식 각주",
                  text: "홍길동, 『논문 작성의 기초』, 서울: ○○출판사, 2024, 15쪽.",
                  color: "var(--brand-indigo)",
                },
                {
                  label: "APA 7판",
                  text: "홍길동. (2024). *논문 작성의 기초*. ○○출판사.",
                  color: "#d97706",
                },
                {
                  label: "MLA 9판",
                  text: "홍길동. *논문 작성의 기초*. ○○출판사, 2024.",
                  color: "#059669",
                },
                {
                  label: "Chicago 17판",
                  text: "홍길동. *논문 작성의 기초*. 서울: ○○출판사, 2024.",
                  color: "#7c3aed",
                },
              ].map(({ label, text, color }) => (
                <div key={label} className="rounded-lg overflow-hidden border border-border">
                  <div
                    className="px-3 py-1.5 text-xs font-semibold text-white"
                    style={{ backgroundColor: color }}
                  >
                    {label}
                  </div>
                  <div className="citation-preview rounded-none border-0 border-l-4" style={{ borderLeftColor: color }}>
                    {text}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 lg:py-20" style={{ backgroundColor: "var(--brand-indigo)" }}>
        <div className="container text-center">
          <h2
            className="text-3xl lg:text-4xl font-bold text-white mb-4"
            style={{ fontFamily: "'Noto Serif KR', serif" }}
          >
            논문 작성의 첫 단계부터
            <br />
            마지막까지
          </h2>
          <p className="text-white/70 mb-8 max-w-md mx-auto">
            형식 걱정 없이 내용에 집중하세요. 논문 도우미가 나머지를 책임집니다.
          </p>
          <div className="flex flex-wrap gap-3 justify-center">
            <Link href="/citation">
              <Button
                size="lg"
                className="gap-2 font-semibold"
                style={{ backgroundColor: "#d97706" }}
              >
                각주 생성기 시작하기
                <ArrowRight size={16} />
              </Button>
            </Link>
            <Link href="/templates">
              <Button
                size="lg"
                variant="outline"
                className="gap-2 font-semibold border-white/30 text-white hover:bg-white/10"
                style={{ backgroundColor: "transparent" }}
              >
                <Download size={16} />
                템플릿 다운로드
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
