import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { z } from "zod";
import { saveCitation, getUserCitations, deleteCitation, saveBibliography, getUserBibliographies, recordTemplateDownload } from "./db";

export const appRouter = router({
    // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // 자료 저장 및 조회 라우터
  citations: router({
    // 자료 저장
    save: protectedProcedure
      .input(z.object({
        type: z.enum(["book", "journal", "web"]),
        author: z.string().min(1),
        title: z.string().min(1),
        publisher: z.string().optional(),
        year: z.number().optional(),
        additionalInfo: z.string().optional(),
        generatedFootnotes: z.object({
          korean: z.string(),
          apa: z.string(),
          mla: z.string(),
          chicago: z.string(),
          krfoundation: z.string(),
        }).optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        if (!ctx.user) throw new Error("Unauthorized");
        const { userId, ...rest } = input as any;
        return await saveCitation(ctx.user.id, rest);
      }),

    // 사용자의 모든 자료 조회
    list: protectedProcedure
      .query(async ({ ctx }) => {
        if (!ctx.user) throw new Error("Unauthorized");
        return await getUserCitations(ctx.user.id);
      }),

    // 자료 삭제
    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ ctx, input }) => {
        if (!ctx.user) throw new Error("Unauthorized");
        return await deleteCitation(input.id, ctx.user.id);
      }),
  }),

  // 참고문헌 목록 라우터
  bibliographies: router({
    // 참고문헌 목록 저장
    save: protectedProcedure
      .input(z.object({
        name: z.string().min(1),
        format: z.enum(["korean", "apa", "mla", "chicago", "krfoundation"]),
        citationIds: z.array(z.number()),
        content: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        if (!ctx.user) throw new Error("Unauthorized");
        const { userId, ...rest } = input as any;
        return await saveBibliography(ctx.user.id, rest);
      }),

    // 사용자의 모든 참고문헌 목록 조회
    list: protectedProcedure
      .query(async ({ ctx }) => {
        if (!ctx.user) throw new Error("Unauthorized");
        return await getUserBibliographies(ctx.user.id);
      }),
  }),

  // 템플릿 다운로드 통계 라우터
  templates: router({
    // 템플릿 다운로드 기록
    recordDownload: protectedProcedure
      .input(z.object({
        templateName: z.enum(["academic", "thesis", "report"]),
      }))
      .mutation(async ({ ctx, input }) => {
        if (!ctx.user) throw new Error("Unauthorized");
        return await recordTemplateDownload(ctx.user.id, input.templateName);
      }),
  }),
});

export type AppRouter = typeof appRouter;
