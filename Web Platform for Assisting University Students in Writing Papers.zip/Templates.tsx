/*
 * Templates.tsx - 논문 템플릿 페이지
 * Design: Clean Scholar - Card grid with format details
 * Features: 학술논문/졸업논문/보고서 템플릿, .docx 다운로드
 */

import { useState } from "react";
import { Download, FileText, ChevronRight, Check, BookOpen, GraduationCap, ClipboardList } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import { saveAs } from "file-saver";
import {
  Document,
  Packer,
  Paragraph,
  TextRun,
  AlignmentType,
  HeadingLevel,
  PageOrientation,
  convertInchesToTwip,
  LineRuleType,
} from "docx";

// ─── Template Definitions ────────────────────────────────────────────────────

interface TemplateSpec {
  id: string;
  name: string;
  description: string;
  icon: React.ComponentType<{ size?: number; className?: string }>;
  badge: string;
  badgeColor: string;
  font: string;
  fontSize: string;
  lineSpacing: string;
  margin: string;
  features: string[];
  structure: string[];
  previewColor: string;
}

const templates: TemplateSpec[] = [
  {
    id: "academic",
    name: "학술 논문",
    description: "학술지 투고용 논문 형식. 한국연구재단 표준 양식을 기반으로 합니다.",
    icon: BookOpen,
    badge: "표준",
    badgeColor: "bg-blue-100 text-blue-700",
    font: "바탕체 (Batang)",
    fontSize: "본문 10pt / 제목 12pt",
    lineSpacing: "줄간격 160%",
    margin: "상하 25mm / 좌우 25mm",
    features: ["한국연구재단 양식", "각주 자동 번호", "참고문헌 섹션", "초록 (국문/영문)"],
    structure: ["표지", "초록 (국문)", "Abstract (영문)", "목차", "본문", "참고문헌"],
    previewColor: "#1e3a5f",
  },
  {
    id: "thesis",
    name: "졸업 논문",
    description: "대학교 졸업 논문 제출용 형식. 일반적인 국내 대학 양식을 따릅니다.",
    icon: GraduationCap,
    badge: "인기",
    badgeColor: "bg-amber-100 text-amber-700",
    font: "신명조 (Shin Myeongjo)",
    fontSize: "본문 11pt / 제목 14pt",
    lineSpacing: "줄간격 180%",
    margin: "상하 30mm / 좌우 30mm",
    features: ["대학 졸업 논문 양식", "표지 페이지", "감사의 글", "목차 자동 생성"],
    structure: ["표지", "인준서", "감사의 글", "목차", "초록", "본문", "참고문헌", "부록"],
    previewColor: "#d97706",
  },
  {
    id: "report",
    name: "학술 보고서",
    description: "수업 과제 및 연구 보고서용 형식. 간결하고 실용적인 구성입니다.",
    icon: ClipboardList,
    badge: "간편",
    badgeColor: "bg-green-100 text-green-700",
    font: "맑은 고딕 (Malgun Gothic)",
    fontSize: "본문 11pt / 제목 13pt",
    lineSpacing: "줄간격 160%",
    margin: "상하 25mm / 좌우 30mm",
    features: ["과제 보고서 형식", "표/그림 캡션", "참고문헌 목록", "페이지 번호"],
    structure: ["표지", "목차", "서론", "본론", "결론", "참고문헌"],
    previewColor: "#059669",
  },
];

// ─── DOCX Generators ─────────────────────────────────────────────────────────

function createAcademicDoc(): Document {
  return new Document({
    styles: {
      default: {
        document: {
          run: { font: "Batang", size: 20 },
        },
      },
    },
    sections: [{
      properties: {
        page: {
          margin: {
            top: convertInchesToTwip(0.98),
            bottom: convertInchesToTwip(0.98),
            left: convertInchesToTwip(0.98),
            right: convertInchesToTwip(0.98),
          },
        },
      },
      children: [
        new Paragraph({
          alignment: AlignmentType.CENTER,
          spacing: { before: 400, after: 200 },
          children: [new TextRun({ text: "논문 제목을 여기에 입력하세요", bold: true, size: 28, font: "Batang" })],
        }),
        new Paragraph({
          alignment: AlignmentType.CENTER,
          spacing: { after: 600 },
          children: [new TextRun({ text: "저자명  소속 기관", size: 22, font: "Batang" })],
        }),
        new Paragraph({
          spacing: { after: 120 },
          children: [new TextRun({ text: "【국문 초록】", bold: true, size: 22, font: "Batang" })],
        }),
        new Paragraph({
          spacing: { after: 400, line: 360, lineRule: LineRuleType.AUTO },
          children: [new TextRun({ text: "본 연구의 목적, 방법, 결과, 결론을 200~300자 내외로 요약하여 작성합니다.", size: 20, font: "Batang" })],
        }),
        new Paragraph({
          spacing: { after: 120 },
          children: [new TextRun({ text: "주제어: ", bold: true, size: 20, font: "Batang" }), new TextRun({ text: "키워드1, 키워드2, 키워드3", size: 20, font: "Batang" })],
        }),
        new Paragraph({ children: [], spacing: { after: 400 } }),
        new Paragraph({
          heading: HeadingLevel.HEADING_1,
          spacing: { before: 400, after: 200 },
          children: [new TextRun({ text: "Ⅰ. 서론", bold: true, size: 24, font: "Batang" })],
        }),
        new Paragraph({
          spacing: { after: 200, line: 360, lineRule: LineRuleType.AUTO },
          children: [new TextRun({ text: "연구의 배경, 목적, 필요성을 서술합니다. 선행 연구를 검토하고 본 연구의 차별성을 명확히 제시합니다.", size: 20, font: "Batang" })],
        }),
        new Paragraph({
          heading: HeadingLevel.HEADING_1,
          spacing: { before: 400, after: 200 },
          children: [new TextRun({ text: "Ⅱ. 이론적 배경", bold: true, size: 24, font: "Batang" })],
        }),
        new Paragraph({
          spacing: { after: 200, line: 360, lineRule: LineRuleType.AUTO },
          children: [new TextRun({ text: "연구와 관련된 이론 및 선행 연구를 체계적으로 검토합니다.", size: 20, font: "Batang" })],
        }),
        new Paragraph({
          heading: HeadingLevel.HEADING_1,
          spacing: { before: 400, after: 200 },
          children: [new TextRun({ text: "Ⅲ. 연구 방법", bold: true, size: 24, font: "Batang" })],
        }),
        new Paragraph({
          spacing: { after: 200, line: 360, lineRule: LineRuleType.AUTO },
          children: [new TextRun({ text: "연구 설계, 연구 대상, 측정 도구, 자료 수집 및 분석 방법을 상세히 기술합니다.", size: 20, font: "Batang" })],
        }),
        new Paragraph({
          heading: HeadingLevel.HEADING_1,
          spacing: { before: 400, after: 200 },
          children: [new TextRun({ text: "Ⅳ. 연구 결과", bold: true, size: 24, font: "Batang" })],
        }),
        new Paragraph({
          spacing: { after: 200, line: 360, lineRule: LineRuleType.AUTO },
          children: [new TextRun({ text: "연구 결과를 객관적으로 서술합니다. 표와 그림을 활용하여 결과를 명확히 제시합니다.", size: 20, font: "Batang" })],
        }),
        new Paragraph({
          heading: HeadingLevel.HEADING_1,
          spacing: { before: 400, after: 200 },
          children: [new TextRun({ text: "Ⅴ. 결론 및 논의", bold: true, size: 24, font: "Batang" })],
        }),
        new Paragraph({
          spacing: { after: 200, line: 360, lineRule: LineRuleType.AUTO },
          children: [new TextRun({ text: "연구 결과를 종합하고, 학문적·실천적 시사점을 제시합니다. 연구의 한계와 향후 연구 방향도 포함합니다.", size: 20, font: "Batang" })],
        }),
        new Paragraph({
          heading: HeadingLevel.HEADING_1,
          spacing: { before: 400, after: 200 },
          children: [new TextRun({ text: "참고문헌", bold: true, size: 24, font: "Batang" })],
        }),
        new Paragraph({
          spacing: { after: 120, line: 360, lineRule: LineRuleType.AUTO },
          children: [new TextRun({ text: "홍길동. (2024). 논문 제목. 학술지명, 30(2), 1-20.", size: 20, font: "Batang" })],
        }),
        new Paragraph({
          spacing: { after: 120, line: 360, lineRule: LineRuleType.AUTO },
          children: [new TextRun({ text: "Kim, C. (2023). Article title. Journal Name, 10(1), 1-15.", size: 20, font: "Batang" })],
        }),
      ],
    }],
  });
}

function createThesisDoc(): Document {
  return new Document({
    styles: {
      default: {
        document: {
          run: { font: "Malgun Gothic", size: 22 },
        },
      },
    },
    sections: [{
      properties: {
        page: {
          margin: {
            top: convertInchesToTwip(1.18),
            bottom: convertInchesToTwip(1.18),
            left: convertInchesToTwip(1.18),
            right: convertInchesToTwip(1.18),
          },
        },
      },
      children: [
        new Paragraph({
          alignment: AlignmentType.CENTER,
          spacing: { before: 1200, after: 400 },
          children: [new TextRun({ text: "○○대학교 학위논문", size: 22, font: "Malgun Gothic" })],
        }),
        new Paragraph({
          alignment: AlignmentType.CENTER,
          spacing: { after: 600 },
          children: [new TextRun({ text: "졸업 논문 제목을 여기에 입력하세요", bold: true, size: 36, font: "Malgun Gothic" })],
        }),
        new Paragraph({
          alignment: AlignmentType.CENTER,
          spacing: { after: 200 },
          children: [new TextRun({ text: "학과명", size: 22, font: "Malgun Gothic" })],
        }),
        new Paragraph({
          alignment: AlignmentType.CENTER,
          spacing: { after: 200 },
          children: [new TextRun({ text: "학번  성명", size: 22, font: "Malgun Gothic" })],
        }),
        new Paragraph({
          alignment: AlignmentType.CENTER,
          spacing: { after: 1200 },
          children: [new TextRun({ text: "지도교수: 교수명", size: 22, font: "Malgun Gothic" })],
        }),
        new Paragraph({
          alignment: AlignmentType.CENTER,
          spacing: { after: 400 },
          children: [new TextRun({ text: "2024년 00월", size: 22, font: "Malgun Gothic" })],
        }),
        new Paragraph({ children: [], pageBreakBefore: true }),
        new Paragraph({
          alignment: AlignmentType.CENTER,
          spacing: { before: 400, after: 400 },
          children: [new TextRun({ text: "감사의 글", bold: true, size: 28, font: "Malgun Gothic" })],
        }),
        new Paragraph({
          spacing: { after: 200, line: 432, lineRule: LineRuleType.AUTO },
          children: [new TextRun({ text: "이 논문이 완성되기까지 도움을 주신 분들에 대한 감사의 말씀을 적습니다.", size: 22, font: "Malgun Gothic" })],
        }),
        new Paragraph({ children: [], pageBreakBefore: true }),
        new Paragraph({
          alignment: AlignmentType.CENTER,
          spacing: { before: 400, after: 400 },
          children: [new TextRun({ text: "국문 초록", bold: true, size: 28, font: "Malgun Gothic" })],
        }),
        new Paragraph({
          spacing: { after: 200, line: 432, lineRule: LineRuleType.AUTO },
          children: [new TextRun({ text: "연구의 목적, 방법, 결과, 결론을 간략히 요약합니다.", size: 22, font: "Malgun Gothic" })],
        }),
        new Paragraph({ children: [], pageBreakBefore: true }),
        new Paragraph({
          heading: HeadingLevel.HEADING_1,
          spacing: { before: 400, after: 200 },
          children: [new TextRun({ text: "제1장  서론", bold: true, size: 28, font: "Malgun Gothic" })],
        }),
        new Paragraph({
          heading: HeadingLevel.HEADING_2,
          spacing: { before: 200, after: 120 },
          children: [new TextRun({ text: "제1절  연구의 배경 및 목적", bold: true, size: 24, font: "Malgun Gothic" })],
        }),
        new Paragraph({
          spacing: { after: 200, line: 432, lineRule: LineRuleType.AUTO },
          children: [new TextRun({ text: "연구의 배경과 목적을 서술합니다.", size: 22, font: "Malgun Gothic" })],
        }),
        new Paragraph({
          heading: HeadingLevel.HEADING_2,
          spacing: { before: 200, after: 120 },
          children: [new TextRun({ text: "제2절  연구의 범위 및 방법", bold: true, size: 24, font: "Malgun Gothic" })],
        }),
        new Paragraph({
          spacing: { after: 200, line: 432, lineRule: LineRuleType.AUTO },
          children: [new TextRun({ text: "연구의 범위와 방법을 서술합니다.", size: 22, font: "Malgun Gothic" })],
        }),
        new Paragraph({
          heading: HeadingLevel.HEADING_1,
          spacing: { before: 400, after: 200 },
          children: [new TextRun({ text: "제2장  이론적 배경", bold: true, size: 28, font: "Malgun Gothic" })],
        }),
        new Paragraph({
          spacing: { after: 200, line: 432, lineRule: LineRuleType.AUTO },
          children: [new TextRun({ text: "관련 이론 및 선행 연구를 검토합니다.", size: 22, font: "Malgun Gothic" })],
        }),
        new Paragraph({
          heading: HeadingLevel.HEADING_1,
          spacing: { before: 400, after: 200 },
          children: [new TextRun({ text: "제3장  연구 방법", bold: true, size: 28, font: "Malgun Gothic" })],
        }),
        new Paragraph({
          spacing: { after: 200, line: 432, lineRule: LineRuleType.AUTO },
          children: [new TextRun({ text: "연구 방법을 상세히 기술합니다.", size: 22, font: "Malgun Gothic" })],
        }),
        new Paragraph({
          heading: HeadingLevel.HEADING_1,
          spacing: { before: 400, after: 200 },
          children: [new TextRun({ text: "제4장  연구 결과", bold: true, size: 28, font: "Malgun Gothic" })],
        }),
        new Paragraph({
          spacing: { after: 200, line: 432, lineRule: LineRuleType.AUTO },
          children: [new TextRun({ text: "연구 결과를 서술합니다.", size: 22, font: "Malgun Gothic" })],
        }),
        new Paragraph({
          heading: HeadingLevel.HEADING_1,
          spacing: { before: 400, after: 200 },
          children: [new TextRun({ text: "제5장  결론", bold: true, size: 28, font: "Malgun Gothic" })],
        }),
        new Paragraph({
          spacing: { after: 200, line: 432, lineRule: LineRuleType.AUTO },
          children: [new TextRun({ text: "연구 결과를 종합하고 시사점을 제시합니다.", size: 22, font: "Malgun Gothic" })],
        }),
        new Paragraph({
          heading: HeadingLevel.HEADING_1,
          spacing: { before: 400, after: 200 },
          children: [new TextRun({ text: "참고문헌", bold: true, size: 28, font: "Malgun Gothic" })],
        }),
        new Paragraph({
          spacing: { after: 120, line: 432, lineRule: LineRuleType.AUTO },
          children: [new TextRun({ text: "홍길동 (2024). 논문 제목. 학술지명, 30(2), 1-20.", size: 22, font: "Malgun Gothic" })],
        }),
      ],
    }],
  });
}

function createReportDoc(): Document {
  return new Document({
    styles: {
      default: {
        document: {
          run: { font: "Malgun Gothic", size: 22 },
        },
      },
    },
    sections: [{
      properties: {
        page: {
          margin: {
            top: convertInchesToTwip(0.98),
            bottom: convertInchesToTwip(0.98),
            left: convertInchesToTwip(1.18),
            right: convertInchesToTwip(1.18),
          },
        },
      },
      children: [
        new Paragraph({
          alignment: AlignmentType.CENTER,
          spacing: { before: 800, after: 400 },
          children: [new TextRun({ text: "보고서 제목을 여기에 입력하세요", bold: true, size: 32, font: "Malgun Gothic" })],
        }),
        new Paragraph({
          alignment: AlignmentType.CENTER,
          spacing: { after: 200 },
          children: [new TextRun({ text: "과목명: ○○○○", size: 22, font: "Malgun Gothic" })],
        }),
        new Paragraph({
          alignment: AlignmentType.CENTER,
          spacing: { after: 200 },
          children: [new TextRun({ text: "담당 교수: ○○○ 교수님", size: 22, font: "Malgun Gothic" })],
        }),
        new Paragraph({
          alignment: AlignmentType.CENTER,
          spacing: { after: 200 },
          children: [new TextRun({ text: "학과: ○○학과  학번: 20240000  이름: 홍길동", size: 22, font: "Malgun Gothic" })],
        }),
        new Paragraph({
          alignment: AlignmentType.CENTER,
          spacing: { after: 800 },
          children: [new TextRun({ text: "제출일: 2024년 00월 00일", size: 22, font: "Malgun Gothic" })],
        }),
        new Paragraph({ children: [], pageBreakBefore: true }),
        new Paragraph({
          heading: HeadingLevel.HEADING_1,
          spacing: { before: 400, after: 200 },
          children: [new TextRun({ text: "1. 서론", bold: true, size: 26, font: "Malgun Gothic" })],
        }),
        new Paragraph({
          spacing: { after: 200, line: 360, lineRule: LineRuleType.AUTO },
          children: [new TextRun({ text: "보고서의 주제, 목적, 범위를 간략히 서술합니다.", size: 22, font: "Malgun Gothic" })],
        }),
        new Paragraph({
          heading: HeadingLevel.HEADING_1,
          spacing: { before: 400, after: 200 },
          children: [new TextRun({ text: "2. 본론", bold: true, size: 26, font: "Malgun Gothic" })],
        }),
        new Paragraph({
          heading: HeadingLevel.HEADING_2,
          spacing: { before: 200, after: 120 },
          children: [new TextRun({ text: "2.1 소제목", bold: true, size: 24, font: "Malgun Gothic" })],
        }),
        new Paragraph({
          spacing: { after: 200, line: 360, lineRule: LineRuleType.AUTO },
          children: [new TextRun({ text: "본론의 내용을 소제목별로 구분하여 서술합니다.", size: 22, font: "Malgun Gothic" })],
        }),
        new Paragraph({
          heading: HeadingLevel.HEADING_2,
          spacing: { before: 200, after: 120 },
          children: [new TextRun({ text: "2.2 소제목", bold: true, size: 24, font: "Malgun Gothic" })],
        }),
        new Paragraph({
          spacing: { after: 200, line: 360, lineRule: LineRuleType.AUTO },
          children: [new TextRun({ text: "추가 내용을 서술합니다.", size: 22, font: "Malgun Gothic" })],
        }),
        new Paragraph({
          heading: HeadingLevel.HEADING_1,
          spacing: { before: 400, after: 200 },
          children: [new TextRun({ text: "3. 결론", bold: true, size: 26, font: "Malgun Gothic" })],
        }),
        new Paragraph({
          spacing: { after: 200, line: 360, lineRule: LineRuleType.AUTO },
          children: [new TextRun({ text: "보고서의 내용을 요약하고 시사점을 제시합니다.", size: 22, font: "Malgun Gothic" })],
        }),
        new Paragraph({
          heading: HeadingLevel.HEADING_1,
          spacing: { before: 400, after: 200 },
          children: [new TextRun({ text: "참고문헌", bold: true, size: 26, font: "Malgun Gothic" })],
        }),
        new Paragraph({
          spacing: { after: 120, line: 360, lineRule: LineRuleType.AUTO },
          children: [new TextRun({ text: "홍길동. (2024). 자료 제목. 출판사.", size: 22, font: "Malgun Gothic" })],
        }),
      ],
    }],
  });
}

// ─── Main Component ──────────────────────────────────────────────────────────

export default function Templates() {
  const [downloading, setDownloading] = useState<string | null>(null);
  const [downloaded, setDownloaded] = useState<string[]>([]);

  const handleDownload = async (template: TemplateSpec) => {
    setDownloading(template.id);
    try {
      let doc: Document;
      let filename: string;

      if (template.id === "academic") {
        doc = createAcademicDoc();
        filename = "학술논문_템플릿.docx";
      } else if (template.id === "thesis") {
        doc = createThesisDoc();
        filename = "졸업논문_템플릿.docx";
      } else {
        doc = createReportDoc();
        filename = "학술보고서_템플릿.docx";
      }

      const blob = await Packer.toBlob(doc);
      saveAs(blob, filename);
      setDownloaded((prev) => [...prev, template.id]);
      toast.success(`${template.name} 템플릿이 다운로드되었습니다.`);
    } catch (err) {
      toast.error("다운로드 중 오류가 발생했습니다.");
    } finally {
      setDownloading(null);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Page Header */}
      <div className="border-b border-border bg-white">
        <div className="container py-8">
          <div className="flex items-center gap-2 text-sm text-muted-foreground mb-3">
            <span>홈</span>
            <ChevronRight size={14} />
            <span style={{ color: "var(--brand-indigo)" }}>템플릿</span>
          </div>
          <h1
            className="text-3xl font-bold mb-2"
            style={{ fontFamily: "'Noto Serif KR', serif", color: "var(--brand-indigo)" }}
          >
            논문 템플릿
          </h1>
          <p className="text-muted-foreground">
            학술 논문, 졸업 논문, 보고서 형식이 적용된 .docx 파일을 무료로 다운로드하세요.
          </p>
        </div>
      </div>

      <div className="container py-8">
        {/* Info Banner */}
        <div
          className="flex items-start gap-3 p-4 rounded-lg mb-8 border"
          style={{
            backgroundColor: "oklch(0.28 0.08 240 / 0.05)",
            borderColor: "oklch(0.28 0.08 240 / 0.2)",
          }}
        >
                    <FileText size={16} className="flex-shrink-0 mt-0.5 text-primary" />
          <div>
            <p className="text-sm font-medium" style={{ color: "var(--brand-indigo)" }}>
              템플릿 사용 안내
            </p>
            <p className="text-sm text-muted-foreground mt-0.5">
              다운로드한 .docx 파일을 Microsoft Word, 한글(HWP) 또는 Google Docs에서 열어 사용하세요.
              HWP 파일 형식은 현재 준비 중입니다.
            </p>
          </div>
          <Badge variant="outline" className="flex-shrink-0 text-xs">
            HWP 준비 중
          </Badge>
        </div>

        {/* Template Cards */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 animate-stagger">
          {templates.map((template) => {
            const Icon = template.icon;
            const isDownloading = downloading === template.id;
            const isDownloaded = downloaded.includes(template.id);

            return (
              <div
                key={template.id}
                className="bg-white rounded-xl border border-border overflow-hidden card-hover flex flex-col"
              >
                {/* Preview Area */}
                <div
                  className="relative h-40 flex items-center justify-center"
                  style={{ backgroundColor: `${template.previewColor}10` }}
                >
                  {/* Document preview mockup */}
                  <div className="relative">
                    <div
                      className="w-24 h-32 rounded-sm shadow-md flex flex-col items-center justify-start pt-3 gap-1.5 bg-white"
                      style={{ border: `2px solid ${template.previewColor}30` }}
                    >
                      <div
                        className="w-16 h-1.5 rounded-full"
                        style={{ backgroundColor: template.previewColor }}
                      />
                      <div className="w-14 h-1 rounded-full bg-gray-200" />
                      <div className="w-14 h-1 rounded-full bg-gray-200" />
                      <div className="w-10 h-1 rounded-full bg-gray-200 mt-1" />
                      <div className="w-14 h-0.5 rounded-full bg-gray-100 mt-1" />
                      <div className="w-14 h-0.5 rounded-full bg-gray-100" />
                      <div className="w-14 h-0.5 rounded-full bg-gray-100" />
                      <div className="w-14 h-0.5 rounded-full bg-gray-100" />
                      <div className="w-14 h-0.5 rounded-full bg-gray-100" />
                      <div className="w-14 h-0.5 rounded-full bg-gray-100" />
                    </div>
                    <div
                      className="absolute -right-3 -bottom-2 w-20 h-28 rounded-sm shadow-sm flex flex-col items-center justify-start pt-2 gap-1 bg-white opacity-60"
                      style={{ border: `1px solid ${template.previewColor}20` }}
                    >
                      <div className="w-12 h-1 rounded-full bg-gray-200" />
                      <div className="w-12 h-0.5 rounded-full bg-gray-100" />
                      <div className="w-12 h-0.5 rounded-full bg-gray-100" />
                    </div>
                  </div>
                  <Badge
                    className={cn("absolute top-3 right-3 text-xs font-medium", template.badgeColor)}
                  >
                    {template.badge}
                  </Badge>
                </div>

                {/* Content */}
                <div className="p-5 flex flex-col flex-1">
                  <div className="flex items-center gap-2.5 mb-2">
                    <div
                      className="w-8 h-8 rounded-md flex items-center justify-center flex-shrink-0"
                      style={{ backgroundColor: `${template.previewColor}15` }}
                    >
                      <Icon size={16} className="opacity-80" />
                    </div>
                    <h3
                      className="font-bold text-lg"
                      style={{ fontFamily: "'Noto Serif KR', serif", color: "var(--brand-indigo)" }}
                    >
                      {template.name}
                    </h3>
                  </div>
                  <p className="text-sm text-muted-foreground mb-4 leading-relaxed">
                    {template.description}
                  </p>

                  {/* Format Details */}
                  <div className="space-y-2 mb-4">
                    <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                      형식 정보
                    </p>
                    <div className="grid grid-cols-2 gap-2">
                      {[
                        { label: "글꼴", value: template.font },
                        { label: "글자 크기", value: template.fontSize },
                        { label: "줄간격", value: template.lineSpacing },
                        { label: "여백", value: template.margin },
                      ].map(({ label, value }) => (
                        <div key={label} className="bg-muted/50 rounded-md p-2">
                          <p className="text-[10px] text-muted-foreground">{label}</p>
                          <p className="text-xs font-medium text-foreground mt-0.5">{value}</p>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Structure */}
                  <div className="mb-4">
                    <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">
                      포함 구성
                    </p>
                    <div className="flex flex-wrap gap-1.5">
                      {template.structure.map((item) => (
                        <span
                          key={item}
                          className="text-xs px-2 py-0.5 rounded-full border border-border text-muted-foreground"
                        >
                          {item}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Features */}
                  <div className="mb-5 flex-1">
                    <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">
                      주요 특징
                    </p>
                    <div className="space-y-1">
                      {template.features.map((feature) => (
                        <div key={feature} className="flex items-center gap-2">
                          <Check size={12} style={{ color: template.previewColor }} className="flex-shrink-0" />
                          <span className="text-xs text-foreground">{feature}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Download Button */}
                  <Button
                    className="w-full gap-2"
                    onClick={() => handleDownload(template)}
                    disabled={isDownloading}
                    style={
                      isDownloaded
                        ? { backgroundColor: "#059669" }
                        : { backgroundColor: "var(--brand-indigo)" }
                    }
                  >
                    {isDownloading ? (
                      <>
                        <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                        생성 중...
                      </>
                    ) : isDownloaded ? (
                      <>
                        <Check size={16} />
                        다운로드 완료
                      </>
                    ) : (
                      <>
                        <Download size={16} />
                        .docx 다운로드
                      </>
                    )}
                  </Button>
                </div>
              </div>
            );
          })}
        </div>

        {/* HWP Notice */}
        <div className="mt-8 p-5 rounded-xl border border-dashed border-border bg-muted/30 text-center">
          <p className="text-sm font-medium text-muted-foreground">
            HWP(한글) 형식 템플릿은 현재 준비 중입니다.
          </p>
          <p className="text-xs text-muted-foreground mt-1">
            .docx 파일은 한글 프로그램에서도 열 수 있습니다. (파일 → 불러오기 → docx 선택)
          </p>
        </div>
      </div>
    </div>
  );
}
