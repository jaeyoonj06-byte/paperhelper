import { eq, and } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, citations, InsertCitation, bibliographies, InsertBibliography, templateDownloads, InsertTemplateDownload } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

/**
 * 사용자의 인용 자료 저장
 */
export async function saveCitation(userId: number, citation: InsertCitation) {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  const result = await db.insert(citations).values({
    ...citation,
    userId,
  });

  return result;
}

/**
 * 사용자의 모든 인용 자료 조회
 */
export async function getUserCitations(userId: number) {
  const db = await getDb();
  if (!db) {
    return [];
  }

  return await db.select().from(citations).where(eq(citations.userId, userId));
}

/**
 * 인용 자료 삭제
 */
export async function deleteCitation(citationId: number, userId: number) {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  return await db.delete(citations).where(
    and(eq(citations.id, citationId), eq(citations.userId, userId))
  );
}

/**
 * 참고문헌 목록 저장
 */
export async function saveBibliography(userId: number, bibliography: InsertBibliography) {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  return await db.insert(bibliographies).values({
    ...bibliography,
    userId,
  });
}

/**
 * 사용자의 모든 참고문헌 목록 조회
 */
export async function getUserBibliographies(userId: number) {
  const db = await getDb();
  if (!db) {
    return [];
  }

  return await db.select().from(bibliographies).where(eq(bibliographies.userId, userId));
}

/**
 * 템플릿 다운로드 기록 저장
 */
export async function recordTemplateDownload(userId: number, templateName: string) {
  const db = await getDb();
  if (!db) {
    return null;
  }

  return await db.insert(templateDownloads).values({
    userId,
    templateName,
  });
}

/**
 * 사용자의 템플릿 다운로드 통계
 */
export async function getUserTemplateStats(userId: number) {
  const db = await getDb();
  if (!db) {
    return [];
  }

  return await db.select().from(templateDownloads).where(eq(templateDownloads.userId, userId));
}
